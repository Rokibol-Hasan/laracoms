<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>CyberMart | My Orders</title>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:title" content="">
    <meta property="og:type" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
    <link rel="shortcut icon" type="image/x-icon" href="user/assets/imgs/theme/favicon.ico">
    <link rel="stylesheet" href="user/assets/css/main.css">
    <link rel="stylesheet" href="user/assets/css/custom.css">
    <script src="https://kit.fontawesome.com/812fd4bca0.js" crossorigin="anonymous"></script>
</head>

<body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.mobile_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="/" rel="nofollow">Home</a>
                    <span></span> Shop
                    <span></span> Your Orders
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <?php if($orderData->isEmpty()): ?>
                    
                    <div class="text-center">
                        <h1>No Order Yet!</h1>
                        <img style="width: 25%" src="/user/assets/imgs/empty-cart-img.png" alt="">
                    </div>
                    <?php else: ?>
                    <div class="col-12 mb-100">
                        <div class="table-responsive">
                            <table class="table shopping-summery text-center clean">
                                <thead>
                                    <tr class="main-heading">
                                        <th scope="col">Product</th>
                                        <th scope="col">Order Tracking ID</th>
                                        <th scope="col">Delivery Status</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Total Price</th>
                                        <th scope="col">View</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <div class="divider center_icon mt-10 mb-30"><b>Active Orders</b></div>
                                <tbody>
                                    <?php $__currentLoopData = $orderData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="image product-thumbnail"><img src="products_images/<?php echo e($order->image); ?>" alt="product_image"></td>
                                        <td>
                                            <span style="color: #2C3333; font-weight: 400;"><?php echo e($order->tracking_id); ?></span>
                                        </td>
                                        <td class="product-des product-name px-5">
                                            <?php if($order->delivery_status == 'pending'): ?>
                                                <i style="color: #54B435; font-size: 17px;" class="fas fa-check"></i>
                                                <span class="product-name px-1">Pending</span>
                                            <?php elseif($order->delivery_status == 'processing'): ?>
                                                <i style="color: #54B435; font-size: 17px;" class="far fa-check-circle"></i>
                                                <span class="product-name px-1">Your Product is Processing</span>
                                            <?php elseif($order->delivery_status == 'packaging'): ?>
                                                <i style="color: #FF577F; font-size: 17px;" class="fas fa-box"></i>
                                                <span class="product-name px-1">Your Product is Being Packaged</span>
                                            <?php elseif($order->delivery_status == 'shipped'): ?>
                                                <i style="color: #AA77FF; font-size: 17px;" class="fas fa-truck-loading"></i>
                                                <span class="product-name px-1">Your Product is Being Shipped</span>
                                            <?php elseif($order->delivery_status == 'on_the_way'): ?>
                                                <i style="color: #FF6000; font-size: 17px;" class="fas fa-truck"></i>
                                                <span class="product-name px-1">Your Product is On the Way</span>
                                            <?php elseif($order->delivery_status == 'delivered'): ?>
                                                <i style="color: #3EC70B; font-size: 17px;" class="fas fa-check-circle"></i>
                                                <span class="product-name px-1">Your Product is Delivered</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center" data-title="Stock">
                                            <div class="detail-qty border radius  m-auto">
                                                <span class="qty-val"><?php echo e($order->quantity); ?></span>
                                            </div>
                                        </td>
                                        <td class="text-right" data-title="Cart">
                                            <span><i style="color: #FF7B54;" class="fas fa-dollar-sign"></i> <?php echo e($order->price); ?></span>
                                        </td>
                                        <td class="action" data-title="View"><a href="#" class="text-muted"><i class="fas fa-eye"></i></a></td>
                                        <td>
                                            <?php if($order->delivery_status == 'pending'): ?>
                                                <a class="btn" href="<?php echo e(url('/cancel-order',$order->id)); ?>"><i class="fas fa-trash"></i> Cancel Order</a>
                                            <?php elseif($order->delivery_status == 'delivered'): ?>
                                                <a class="btn" href="<?php echo e(url('/order-received',$order->id)); ?>"> I received my products</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php echo $__env->make('user.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-12">
                        <div class="table-responsive">
                            <table class="table shopping-summery text-center clean">
                                <thead>
                                    <tr class="main-heading">
                                        <th scope="col">Product</th>
                                        <th scope="col">Order Tracking ID</th>
                                        <th scope="col">Delivery Status</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Total Price</th>
                                        <th scope="col">View</th>
                                    </tr>
                                </thead>
                                <div class="divider center_icon mt-100 mb-30"><b>Past Orders</b></div>
                                <tbody>
                                    <?php $__currentLoopData = $past_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="image product-thumbnail"><img src="products_images/<?php echo e($order->image); ?>" alt="product_image"></td>
                                        <td>
                                            <span style="color: #2C3333; font-weight: 400;"><?php echo e($order->tracking_id); ?></span>
                                        </td>
                                        <td class="product-des product-name px-5">
                                            <i style="color: #3EC70B; font-size: 17px;" class="fas fa-check-circle"></i>
                                            <span class="product-name px-1">Product is received by user</span>
                                        </td>
                                        <td class="text-center" data-title="Stock">
                                            <div class="detail-qty border radius  m-auto">
                                                <span class="qty-val"><?php echo e($order->quantity); ?></span>
                                            </div>
                                        </td>
                                        <td class="text-right" data-title="Cart">
                                            <span><i style="color: #FF7B54;" class="fas fa-dollar-sign"></i> <?php echo e($order->price); ?></span>
                                        </td>
                                        <td class="action" data-title="View"><a href="<?php echo e(url('/product_details', $order->product_id)); ?>" class="text-muted"><i class="fas fa-eye"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>

    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    <!-- Vendor JS-->
    <script src="user/assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="user/assets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="user/assets/js/vendor/jquery-migrate-3.3.0.min.js"></script>
    <script src="user/assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="user/assets/js/plugins/slick.js"></script>
    <script src="user/assets/js/plugins/jquery.syotimer.min.js"></script>
    <script src="user/assets/js/plugins/wow.js"></script>
    <script src="user/assets/js/plugins/jquery-ui.js"></script>
    <script src="user/assets/js/plugins/perfect-scrollbar.js"></script>
    <script src="user/assets/js/plugins/magnific-popup.js"></script>
    <script src="user/assets/js/plugins/select2.min.js"></script>
    <script src="user/assets/js/plugins/waypoints.js"></script>
    <script src="user/assets/js/plugins/counterup.js"></script>
    <script src="user/assets/js/plugins/jquery.countdown.min.js"></script>
    <script src="user/assets/js/plugins/images-loaded.js"></script>
    <script src="user/assets/js/plugins/isotope.js"></script>
    <script src="user/assets/js/plugins/scrollup.js"></script>
    <script src="user/assets/js/plugins/jquery.vticker-min.js"></script>
    <script src="user/assets/js/plugins/jquery.theia.sticky.js"></script>
    <script src="user/assets/js/plugins/jquery.elevatezoom.js"></script>
    <!-- Template  JS -->
    <script src="user/assets/js/main.js?v=3.3"></script>
    <script src="user/assets/js/shop.js?v=3.3"></script></body>

</html><?php /**PATH F:\xampp\htdocs\laracom\resources\views/user/orders.blade.php ENDPATH**/ ?>