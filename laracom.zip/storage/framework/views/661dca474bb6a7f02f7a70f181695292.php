<section class="featured section-padding position-relative">
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-4 mb-md-3 mb-lg-0">
                <div class="banner-features wow fadeIn animated hover-up">
                    <img src="user/assets/imgs/theme/icons/feature-1.png" alt="">
                    <h4 class="bg-1">Free Shipping</h4>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-md-3 mb-lg-0">
                <div class="banner-features wow fadeIn animated hover-up">
                    <img src="user/assets/imgs/theme/icons/feature-2.png" alt="">
                    <h4 class="bg-3">Online Order</h4>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-md-3 mb-lg-0">
                <div class="banner-features wow fadeIn animated hover-up">
                    <img src="user/assets/imgs/theme/icons/feature-3.png" alt="">
                    <h4 class="bg-2">Save Money</h4>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-md-3 mb-lg-0">
                <div class="banner-features wow fadeIn animated hover-up">
                    <img src="user/assets/imgs/theme/icons/feature-4.png" alt="">
                    <h4 class="bg-4">Promotions</h4>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-md-3 mb-lg-0">
                <div class="banner-features wow fadeIn animated hover-up">
                    <img src="user/assets/imgs/theme/icons/feature-5.png" alt="">
                    <h4 class="bg-5">Happy Sell</h4>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-md-3 mb-lg-0">
                <div class="banner-features wow fadeIn animated hover-up">
                    <img src="user/assets/imgs/theme/icons/feature-6.png" alt="">
                    <h4 class="bg-6">24/7 Support</h4>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH F:\xampp\htdocs\laracom\resources\views/user/app_features.blade.php ENDPATH**/ ?>