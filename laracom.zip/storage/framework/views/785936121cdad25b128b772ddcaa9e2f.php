<section class="banner-2 section-padding pb-0">
    <div class="container">
        <div class="banner-img banner-big wow fadeIn animated f-none">
            <img src="user/assets/imgs/banner/banner.png" alt="">
            <div class="banner-text d-md-block d-none">
                <a href="<?php echo e(route('user.shop')); ?>" class="btn">Learn More <i class="fi-rs-arrow-right"></i></a>
            </div>
        </div>
    </div>
</section><?php /**PATH F:\xampp\htdocs\laracom\resources\views/user/banner.blade.php ENDPATH**/ ?>